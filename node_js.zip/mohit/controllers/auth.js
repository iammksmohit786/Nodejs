const User = require("../models/user");
const { validationResult } = require("express-validator");
const jwt = require("jsonwebtoken");
var expressJwt = require("express-jwt");

exports.signup = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ error: errors.array()[0].msg });
  }
  const user = new User(req.body);
  user
    .save()
    .then((user) =>
      res.status(201).json({
        name: user.name,
        email: user.email,
        id: user._id,
      })
    )
    .catch((err) =>
      res.status(400).json({
        err: "Not able to save data in DB!",
        errmsg: err.errmsg,
      })
    );
};

exports.signin = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({ error: errors.array()[0].msg });
  }

  try {
    const { password } = req.body;
    const user = await User.findOne({ email: req.body.email });

    if (!user) {
      return res.status(400).json({ error: "User email does not exist" });
    }

    // console.log(user.authenticate(password));
    if (!user.hashedPassword(password)) {
      return res
        .status(401)
        .json({ error: "User email or password not correct" });
    }

    //create token
    const token = jwt.sign({ _id: user._id }, process.env.SECRET);
    //put token in cookie
    res.cookie("token", token, { expire: new Date() + 9999 });

    //send response to frontend
    const { _id, name, email, role } = user;
    return res.json({ token, User: { _id, name, email, role } });
  } catch (error) {
    console.log(error);
  }
};

exports.signout = (req, res) => {
  res.clearCookie("token");
  res.json({
    user: "user signout successfully !",
  });
};

//protected routes

exports.isSignIn = expressJwt({
  secret: process.env.SECRET,
  requestProperty: "auth",
});

// const error = errors.array().reduce((acc, value) => {
//   acc[value.param] = value.msg;
//   return acc;
// }, {});
