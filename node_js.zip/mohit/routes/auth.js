const express = require("express");
const router = express.Router();

const { check } = require("express-validator");

const { signout, signup, signin, isSignIn } = require("../controllers/auth");

const signUpValidator = [
  check("name")
    .isLength({ min: 3 })
    .withMessage("name must be at least 3 characters long !"),
  check("email").isEmail().withMessage("must be a email !"),
  check("password")
    .isLength({ min: 4 })
    .withMessage("must be at least 5 characters long "),
];
const signInValidator = [
  check("email").isEmail().withMessage("must be a email !"),
  check("password")
    .isLength({ min: 1 })
    .withMessage("password field is required !"),
];

router.post("/signup", signUpValidator, signup);

router.post("/signin", signInValidator, signin);

router.get("/signout", signout);

module.exports = router;
